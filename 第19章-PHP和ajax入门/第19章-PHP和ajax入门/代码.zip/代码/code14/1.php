<?php
    header('content-type:text/html;charset="utf-8"');
    $str = $_GET["str"];
    echo $str;
?>